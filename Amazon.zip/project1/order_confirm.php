<?php
	session_start();
	 $userprofile = $_SESSION['user_name'];
	if($userprofile)
	{
        
        

// Check if the user's email is set in the session
if (isset($_SESSION['user_name'])) {
  $user_email = $_SESSION['user_name'];
}

// Sample session cart items and total price (should already be set in Checkout.php)
$cart_items = $_SESSION['cart'] ?? [];  // Get cart items from session
$total_price = 0;

// Calculate total price
foreach ($cart_items as $item) {
    $total_price += $item['price'] * $item['quantity'];
}

// Simulated order number and delivery date (replace with real logic if needed)
$order_number = strtoupper(uniqid('ORDER-'));
$delivery_date = date('F j, Y', strtotime("+5 days"));

// Store the order details in the session
$_SESSION['orders'][] = [
    'order_number' => $order_number,
    'order_date' => date('F j, Y'),
    'delivery_date' => $delivery_date,
    'total_price' => $total_price,
    'status' => 'Processing',  // Initial status
    'items' => $cart_items
];

unset($_SESSION['cart']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Confirmation</title>
  <link rel="stylesheet" href="css/order.css?v=<?php echo time(); ?>">
  <link rel = "stylesheet" href="css/style1.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
    <!-- header -->

    <header>
        <div class="navbar">
            <div class="nav-logo border">
                <a href = "index.php">
                <div class="logo">
                </div>
                </a>
            </div>

            <div class="nav-address border">
                <p class = "add-first">Dilever to</p>
                <div class="add-icon">
                    <i class="fa-solid fa-location-dot"></i>
                    <p class = "add-sec">
                        India
                    </p>
                </div>
            </div>

            <div class="nav-search">
                <select class = "search-select">
                    <option>All</option>
                </select>
                <input type="text" placeholder="Search Amazon" class = "search-input"/>
                <div class="search-icon">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </div>
            </div>

            <div class="nav-signin border">
                <p>
                <?php
                    if (isset($_SESSION['user_name'])) {
                        // Display the user's name from the session
                        echo "<span>Hello, " . htmlspecialchars($_SESSION['user_name']) . "</span>";
                    } else {
                        echo "<span>Hello, sign in</span>";
                    }
                    ?>
                </p>            
                <p class ="nav-second">Account & Lists</p>
            </div>

            <a href = "orders.php" style = "text-decoration:none;color:white;">
            <div class="nav-return border">
                <p>
                    <span>Returns</span>
                </p>            
                <p class ="nav-second">& Orders </p>
            </div>
            </a>
            <a href = "cart.php" style="text-decoration:none;color:white;">
            <div class="nav-cart border">
                <i class="fa-solid fa-cart-shopping"></i>
                Cart
            </div>
	        </a>

            <div class="nav-logout">
              <a href = "logout.php">
                <input type = "submit" value = "LOGOUT"  class = "logout"/>
              </a>
            </div>
        </div>

        <div class="pannel">
            <div class="pannel-all border padding">
                <i class="fa-solid fa-bars"></i>
                All    
            </div>
            <div class="pannel-ops">
                <a class="border padding">Today's Deals</a>
                <a class="border padding">Customer Services</a>
                <a class="border padding">Registry</a>
                <a class="border padding">Gift Cards</a>
                <a class="border padding">Sell</a>
            </div>
            <div class="pennel-deals border padding">
                <p>Shop the Gaming Store</p>
            </div>
        </div>
    </header>


<div class="confirm_order">
<div class="container">
  <div class="confirmation-header amazon-logo">
  <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="Amazon Logo">
    <h1>Thank you, your order has been placed!</h1>
  </div>

  <div class="order-info">
    <p>Order Number: <strong><?php echo $order_number; ?></strong></p>
    <p>We’ve sent a confirmation email to <strong><?php echo htmlspecialchars($user_email); ?>@gmail.com</strong></p>
    <p>Estimated delivery date: <strong><?php echo $delivery_date; ?></strong></p>
  </div>

  <div class="order-summary">
    <h2>Order Summary</h2>
    <table>
      <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
      </tr>
      <?php foreach ($cart_items as $item): ?>
      <tr>
        <td><?php echo htmlspecialchars($item['name']); ?></td>
        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
        <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <div class="total-amount">
    <strong>Total: $<?php echo number_format($total_price, 2); ?></strong>
  </div>

  <!--<div class="order-actions">
    <a href="index.php">Browes More Products</a>
  </div>-->

  <div class="actions">
            <a href="index.php" class="continue-shopping">Continue Shopping</a>
            <a href="orders.php" class="view-orders">View Your Orders</a>
        </div>

  <div class="footer">
    <p>Need help? Visit our <a href="#">Help Center</a>.</p>
  </div>
</div>
</div>

<footer>
        <a style ="cursor:pointer;">
        <div class="foot-pannel1" id = "backToTop">
            Back to top
        </div>
                </a>
        <div class="foot-pannel2">
            <ul>
                <p>Get to Know Us</p>
                <a>Careers</a>
                <a>Blog</a>
                <a>About Amazon</a>
                <a>Investor Relations</a>
                <a>Amazon Devices</a>
                <a>Amazon Science</a>
            </ul>
            <ul>
                <p>Make Money with Us</p>
                <a>Sell products on Amazon</a>
                <a>Sell on Amazon Business</a>
                <a>Sell apps on Amazon</a>
                <a>Become an Affiliates</a>
                <a>Advertise Your Productss</a>
                <a>Self-Publish with Us</a>
                <a>Host an Amazon Hub</a>
                <a>› See More Make Money with Us</a>
            </ul>
            <ul>
                <p>Amazon Payment Products</p>
                <a>Amazon Business Card</a>
                <a>Shop with Points</a>
                <a>Reload Your Balance</a>
                <a>Amazon Currency Converters</a>
            </ul>
            <ul>
                <p>Let Us Help You</p>
                <a>Amazon and COVID-19</a>
                <a>Your Account</a>
                <a>Your Orders</a>
                <a>Shipping Rates & Policies</a>
                <a>Returns & Replacements</a>
                <a>Manage Your Content and Devices</a>
                <a>Help</a>
            </ul>
        </div>

        <div class="foot-pannel3">
            <div class="logo"></div>
        </div>
        
        <div class="foot-pannel4">
            <div class="pages">
                <a>Conditions of Use</a>
                <a>Privacy Notice</a>
                <a>Your Ads Privacy Choices</a>
            </div>
            <div class="copyright">
                © 1996-2024, Amazon.com, Inc. or its affiliates
            </div>
        </div>
    </footer>

    <script>
    // Scroll to the top when the "Back to top" is clicked
    document.getElementById("backToTop").addEventListener("click", function() {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
</script>


</body>
</html>

<?php
}
else {
header('location:login.php');
}
?>