document.addEventListener('DOMContentLoaded', function () {
    // Get the form element
    const checkoutForm = document.getElementById('checkoutForm');

    // Add event listener for form submission
    checkoutForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get form values
        const fullName = document.getElementById('fullName').value;
        const address = document.getElementById('address').value;
        const city = document.getElementById('city').value;
        const zip = document.getElementById('zip').value;
        const country = document.getElementById('country').value;
        const cardNumber = document.getElementById('cardNumber').value;
        const expDate = document.getElementById('expDate').value;
        const cvv = document.getElementById('cvv').value;

        // Validate form fields (simple validation)
        if (!fullName || !address || !city || !zip || !cardNumber || !expDate || !cvv) {
            alert('Please fill out all required fields.');
            return;
        }

        // Confirm order with user, using the dynamically set totalPrice variable
        const confirmOrder = confirm(`You are about to place the following order:\n\n
        Name: ${fullName}\n
        Address: ${address}, ${city}, ${zip}, ${country}\n
        Total: ${totalPrice}\n\n
        Click OK to confirm.`);
        window.location.href = 'order_confirm.php';


        if (confirmOrder) {
            // Simulate order placement (in real case, you would send data to the server)
            alert('Thank you! Your order has been placed successfully.');

            
             window.location.href = 'order_confirm.php';
        }
    });
});